import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile as firebaseUpdateProfile,
  type User,
} from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  profileName: string;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (
    email: string,
    password: string,
    name: string,
  ) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  updateProfile: (name: string) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profileName, setProfileName] = useState("");
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (uid: string) => {
    try {
      const snap = await getDoc(doc(db, "profiles", uid));
      if (snap.exists()) {
        const data = snap.data() as { name?: string };
        setProfileName(data.name ?? "");
      } else {
        setProfileName("");
      }
    } catch {
      setProfileName("");
    }
  }, []);

  useEffect(() => {
    // Register the listener BEFORE any session restore so it is never missed.
    const unsubscribe = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setLoading(false);
      if (nextUser) {
        void loadProfile(nextUser.uid);
      } else {
        setProfileName("");
      }
    });
    return unsubscribe;
  }, [loadProfile]);

  const signIn = useCallback(async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      return { error: null };
    } catch (err) {
      return { error: (err as Error).message };
    }
  }, []);

  const signUp = useCallback(async (email: string, password: string, name: string) => {
    try {
      const credential = await createUserWithEmailAndPassword(auth, email, password);
      const trimmed = name.trim();
      if (trimmed) {
        await firebaseUpdateProfile(credential.user, { displayName: trimmed });
      }
      const now = new Date().toISOString();
      await setDoc(doc(db, "profiles", credential.user.uid), {
        name: trimmed,
        createdAt: now,
        updatedAt: now,
      });
      setProfileName(trimmed);
      return { error: null };
    } catch (err) {
      return { error: (err as Error).message };
    }
  }, []);

  const signOut = useCallback(async () => {
    await firebaseSignOut(auth);
  }, []);

  const updateProfile = useCallback(
    async (name: string) => {
      if (!user) return { error: "尚未登入" };
      const trimmed = name.trim();
      try {
        await firebaseUpdateProfile(user, { displayName: trimmed });
        await setDoc(
          doc(db, "profiles", user.uid),
          { name: trimmed, updatedAt: new Date().toISOString() },
          { merge: true },
        );
        setProfileName(trimmed);
        return { error: null };
      } catch (err) {
        return { error: (err as Error).message };
      }
    },
    [user],
  );

  return (
    <AuthContext.Provider
      value={{ user, loading, profileName, signIn, signUp, signOut, updateProfile }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
