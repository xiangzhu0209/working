import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

/**
 * 請填入您在 Firebase 控制台取得的網頁應用程式設定值：
 * Firebase 控制台 → 專案設定（齒輪圖示）→ 一般 → 您的應用程式 → 網頁應用程式 SDK 設定
 */
const firebaseConfig = {
  apiKey: "AIzaSyBNxG3huOenZKAaDw-ezHyB9Hj9IAXMawE",
  authDomain: "working-c983a.firebaseapp.com",
  projectId: "working-c983a",
  storageBucket: "working-c983a.firebasestorage.app",
  messagingSenderId: "108786632940",
  appId: "1:108786632940:web:05505960c21b3a7e1cfdc9",
  measurementId: "G-8QH8EKTZKY",
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
