export interface Profile {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

export interface Vendor {
  id: string;
  userId: string;
  name: string;
  phone: string;
  notes: string;
  createdAt: string;
}

export interface PriceItem {
  id: string;
  userId: string;
  vendorId: string;
  productName: string;
  spec: string;
  unit: string;
  unitPrice: number;
  notes: string;
  createdAt: string;
}

export interface Order {
  id: string;
  userId: string;
  orderNo: string;
  orderDate: string;
  customerName: string;
  projectName: string;
  status: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

/**
 * Order item. Order-level fields (orderNo / orderDate / customerName /
 * vendorName) are denormalized onto each item so lists, printing and
 * reconciliation never need joins.
 */
export interface OrderItem {
  id: string;
  userId: string;
  orderId: string;
  orderNo: string;
  orderDate: string;
  customerName: string;
  vendorId: string | null;
  vendorName: string;
  productName: string;
  size: string;
  spec: string;
  quantity: number;
  unitPrice: number;
  notes: string;
  createdAt: string;
}

/** Client-side editable line item for the order form (numeric fields as text). */
export interface OrderItemDraft {
  key: string;
  product_name: string;
  size: string;
  spec: string;
  quantity: string;
  unit_price: string;
  notes: string;
}
