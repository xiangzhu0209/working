import { collection, getDocs, query, where } from "firebase/firestore";
import { db } from "./firebase";

/**
 * Fetches documents whose `userId` equals `uid` and whose `field` value is in
 * `values`, batching by 10 (Firestore `in` queries accept at most 10 values).
 * The userId filter is required so queries stay allowed by the security rules.
 */
export async function fetchInChunks<T>(
  collectionName: string,
  field: string,
  values: string[],
  uid: string,
): Promise<T[]> {
  const results: T[] = [];
  for (let i = 0; i < values.length; i += 10) {
    const chunk = values.slice(i, i + 10);
    const q = query(
      collection(db, collectionName),
      where("userId", "==", uid),
      where(field, "in", chunk),
    );
    const snap = await getDocs(q);
    for (const d of snap.docs) {
      results.push({ id: d.id, ...d.data() } as T);
    }
  }
  return results;
}
