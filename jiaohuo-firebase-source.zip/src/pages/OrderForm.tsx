import { useMemo, useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, BookOpen, Plus, Save, Trash2, X } from "lucide-react";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  query,
  updateDoc,
  where,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import type { Order, OrderItem, OrderItemDraft, PriceItem, Vendor } from "@/lib/types";
import { fmtMoney, generateOrderNo, STATUS_LABELS, toNum } from "@/lib/order-utils";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";

interface VendorSection {
  vendorId: string;
  rows: OrderItemDraft[];
}

const newDraft = (): OrderItemDraft => ({
  key: crypto.randomUUID(),
  product_name: "",
  size: "",
  spec: "",
  quantity: "",
  unit_price: "",
  notes: "",
});

export default function OrderForm() {
  const { id } = useParams();
  const isEdit = !!id;
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { user } = useAuth();
  const uid = user?.id ?? "";

  const [orderDate, setOrderDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [customerName, setCustomerName] = useState("");
  const [projectName, setProjectName] = useState("");
  const [status, setStatus] = useState("draft");
  const [notes, setNotes] = useState("");
  const [sections, setSections] = useState<VendorSection[]>([]);
  const [picker, setPicker] = useState<{ sectionIndex: number; rowKey: string } | null>(null);

  const { data: vendors = [] } = useQuery({
    queryKey: ["vendors", uid],
    enabled: !!uid,
    queryFn: async () => {
      const q = query(collection(db, "vendors"), where("userId", "==", uid));
      const snap = await getDocs(q);
      return snap.docs
        .map((d) => ({ id: d.id, ...d.data() }) as Vendor)
        .sort((a, b) => a.name.localeCompare(b.name));
    },
  });

  const vendorNameById = useMemo(() => {
    const map = new Map<string, string>();
    for (const v of vendors) map.set(v.id, v.name);
    return map;
  }, [vendors]);

  const pricesVendorId = picker ? (sections[picker.sectionIndex]?.vendorId ?? "") : "";

  const { data: prices = [] } = useQuery({
    queryKey: ["prices", uid, pricesVendorId],
    enabled: !!uid && !!pricesVendorId,
    queryFn: async () => {
      const q = query(
        collection(db, "priceList"),
        where("userId", "==", uid),
        where("vendorId", "==", pricesVendorId),
      );
      const snap = await getDocs(q);
      return snap.docs
        .map((d) => ({ id: d.id, ...d.data() }) as PriceItem)
        .sort((a, b) => a.productName.localeCompare(b.productName));
    },
  });

  // History of every 色號's most recent unit price (per vendor), used to
  // auto-fill the 單價 when a previously-used 色號 is typed again.
  const { data: priceHistory = [] } = useQuery({
    queryKey: ["price-history", uid],
    enabled: !!uid,
    queryFn: async () => {
      const q = query(collection(db, "orderItems"), where("userId", "==", uid));
      const snap = await getDocs(q);
      return snap.docs.map((d) => ({ id: d.id, ...d.data() }) as OrderItem);
    },
  });

  const latestPriceByKey = useMemo(() => {
    const map = new Map<string, number>();
    const sorted = [...priceHistory].sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt),
    );
    for (const it of sorted) {
      const key = `${it.vendorId ?? ""}||${it.productName}`;
      if (!map.has(key)) map.set(key, toNum(it.unitPrice));
    }
    return map;
  }, [priceHistory]);

  // Load existing order (edit mode)
  const { isLoading: loadingOrder } = useQuery({
    queryKey: ["order", uid, id],
    enabled: isEdit && !!uid,
    queryFn: async () => {
      const orderSnap = await getDoc(doc(db, "orders", id!));
      if (!orderSnap.exists()) throw new Error("找不到這張叫貨單");
      const order = { id: orderSnap.id, ...orderSnap.data() } as Order;

      const q = query(
        collection(db, "orderItems"),
        where("userId", "==", uid),
        where("orderId", "==", id!),
      );
      const snap = await getDocs(q);
      const orderItems = snap.docs.map((d) => ({ id: d.id, ...d.data() }) as OrderItem);

      setOrderDate(order.orderDate);
      setCustomerName(order.customerName ?? "");
      setProjectName(order.projectName ?? "");
      setStatus(order.status);
      setNotes(order.notes ?? "");

      const groups = new Map<string, OrderItemDraft[]>();
      for (const it of orderItems) {
        const key = it.vendorId ?? "";
        const list = groups.get(key) ?? [];
        list.push({
          key: crypto.randomUUID(),
          product_name: it.productName,
          size: it.size ?? "",
          spec: it.spec ?? "",
          quantity: String(it.quantity),
          unit_price: String(it.unitPrice),
          notes: it.notes ?? "",
        });
        groups.set(key, list);
      }
      setSections([...groups.entries()].map(([vendorId, rows]) => ({ vendorId, rows })));
      return order;
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const now = new Date().toISOString();
      const orderPayload = {
        userId: uid,
        orderDate,
        customerName: customerName.trim(),
        projectName: projectName.trim(),
        status,
        notes: notes.trim(),
      };

      let orderId: string;
      let orderNo: string;
      if (isEdit) {
        orderId = id!;
        // orderNo is read back from the existing doc
        const current = await getDoc(doc(db, "orders", id!));
        if (!current.exists()) throw new Error("找不到這張叫貨單");
        orderNo = (current.data() as Order).orderNo;
        await updateDoc(doc(db, "orders", orderId), {
          ...orderPayload,
          orderNo,
          updatedAt: now,
        });
        const oldItems = await getDocs(
          query(
            collection(db, "orderItems"),
            where("userId", "==", uid),
            where("orderId", "==", orderId),
          ),
        );
        await Promise.all(oldItems.docs.map((d) => deleteDoc(doc(db, "orderItems", d.id))));
      } else {
        const allOrders = await getDocs(
          query(collection(db, "orders"), where("userId", "==", uid)),
        );
        const todayNos = allOrders.docs
          .map((d) => (d.data() as Order).orderNo)
          .filter((no) => no.startsWith(`JA-${orderDate.replaceAll("-", "")}-`));
        orderNo = generateOrderNo(todayNos, new Date(orderDate + "T00:00:00"));
        const created = await addDoc(collection(db, "orders"), {
          ...orderPayload,
          orderNo,
          createdAt: now,
          updatedAt: now,
        });
        orderId = created.id;
      }

      const items = sections.flatMap((s) =>
        s.rows
          .filter((r) => r.product_name.trim() !== "")
          .map((r) => {
            const historyPrice = latestPriceByKey.get(
              `${s.vendorId ?? ""}||${r.product_name.trim()}`,
            );
            return {
              userId: uid,
              orderId,
              orderNo,
              orderDate,
              customerName: customerName.trim(),
              vendorId: s.vendorId || null,
              vendorName: s.vendorId ? (vendorNameById.get(s.vendorId) ?? "") : "",
              productName: r.product_name.trim(),
              size: r.size.trim(),
              spec: r.spec.trim(),
              quantity: Number(r.quantity) || 0,
              unitPrice: Number(r.unit_price) || historyPrice || 0,
              notes: r.notes.trim(),
              createdAt: now,
            };
          }),
      );

      await Promise.all(items.map((it) => addDoc(collection(db, "orderItems"), it)));
      return orderId;
    },
    onSuccess: (createdId) => {
      toast(isEdit ? "叫貨單已更新" : "叫貨單已建立");
      void qc.invalidateQueries({ queryKey: ["orders", uid] });
      void qc.invalidateQueries({ queryKey: ["price-history", uid] });
      navigate(`/orders/${createdId}/print`);
    },
    onError: (err) => toast(`儲存失敗：${(err as Error).message}`),
  });

  const updateSectionVendor = (sectionIndex: number, vendorId: string) => {
    setSections((prev) =>
      prev.map((s, i) => (i === sectionIndex ? { ...s, vendorId } : s)),
    );
  };

  const updateItem = (sectionIndex: number, key: string, patch: Partial<OrderItemDraft>) => {
    setSections((prev) =>
      prev.map((s, i) =>
        i === sectionIndex
          ? {
              ...s,
              rows: s.rows.map((r) => (r.key === key ? { ...r, ...patch } : r)),
            }
          : s,
      ),
    );
  };

  const removeItem = (sectionIndex: number, key: string) => {
    setSections((prev) =>
      prev.map((s, i) =>
        i === sectionIndex ? { ...s, rows: s.rows.filter((r) => r.key !== key) } : s,
      ),
    );
  };

  const removeSection = (sectionIndex: number) => {
    setSections((prev) => prev.filter((_, i) => i !== sectionIndex));
  };

  const addSection = () => {
    setSections((prev) => [...prev, { vendorId: "", rows: [newDraft()] }]);
  };

  const addRow = (sectionIndex: number) => {
    setSections((prev) =>
      prev.map((s, i) => (i === sectionIndex ? { ...s, rows: [...s.rows, newDraft()] } : s)),
    );
  };

  const addRowFromPrice = (sectionIndex: number) => {
    const key = crypto.randomUUID();
    setSections((prev) =>
      prev.map((s, i) =>
        i === sectionIndex
          ? { ...s, rows: [...s.rows, { ...newDraft(), key }] }
          : s,
      ),
    );
    setPicker({ sectionIndex, rowKey: key });
  };

  const applyPrice = (p: PriceItem) => {
    if (!picker) return;
    updateItem(picker.sectionIndex, picker.rowKey, {
      product_name: p.productName,
      spec: p.spec ?? "",
      unit_price: String(p.unitPrice),
    });
    setPicker(null);
  };

  // When a previously-used 色號 is typed, fill in the last unit price for that
  // vendor + 色號 (only when the price field is still empty).
  const autoFillPrice = (sectionIndex: number, key: string) => {
    setSections((prev) =>
      prev.map((s, i) => {
        if (i !== sectionIndex) return s;
        const row = s.rows.find((r) => r.key === key);
        if (!row) return s;
        const name = row.product_name.trim();
        if (!name || row.unit_price !== "") return s;
        const price = latestPriceByKey.get(`${s.vendorId ?? ""}||${name}`);
        if (price === undefined) return s;
        return {
          ...s,
          rows: s.rows.map((r) =>
            r.key === key ? { ...r, unit_price: String(price) } : r,
          ),
        };
      }),
    );
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const issues: string[] = [];
    sections.forEach((s, i) => {
      const hasItems = s.rows.some((r) => r.product_name.trim() !== "");
      if (hasItems && !s.vendorId) issues.push(`第 ${i + 1} 個廠商區塊尚未選擇廠商`);
    });
    const totalRows = sections.reduce(
      (n, s) => n + s.rows.filter((r) => r.product_name.trim() !== "").length,
      0,
    );
    if (issues.length > 0) {
      toast(issues.join("；"));
      return;
    }
    if (totalRows === 0) {
      toast("請至少加入一筆明細");
      return;
    }
    saveMutation.mutate();
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      {loadingOrder ? (
        <p className="py-16 text-center text-sm text-muted-foreground">載入中…</p>
      ) : (
        <>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Button type="button" variant="ghost" size="icon" onClick={() => navigate("/orders")}>
                <ArrowLeft className="size-4" />
              </Button>
              <div>
                <h1 className="text-2xl font-semibold tracking-tight">
                  {isEdit ? "編輯叫貨單" : "新增叫貨單"}
                </h1>
                <p className="text-sm text-muted-foreground">
                  先填客戶資料，再依廠商分開輸入要叫的貨
                </p>
              </div>
            </div>
            <Button type="submit" disabled={saveMutation.isPending || !uid}>
              <Save className="size-4" />
              {saveMutation.isPending ? "儲存中…" : "儲存叫貨單"}
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">客戶資料</CardTitle>
              <CardDescription>日期與客戶資訊</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <div className="flex flex-col gap-2">
                <Label htmlFor="o-date">日期 *</Label>
                <Input
                  id="o-date"
                  type="date"
                  value={orderDate}
                  onChange={(e) => setOrderDate(e.target.value)}
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="o-customer">客戶名</Label>
                <Input
                  id="o-customer"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="例如：賴韶宜"
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="o-project">案名</Label>
                <Input
                  id="o-project"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="例如：中和路"
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label>狀態</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(STATUS_LABELS).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-2 sm:col-span-2 lg:col-span-2">
                <Label htmlFor="o-notes">訂單備註</Label>
                <Input
                  id="o-notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="例如：急件 / 先送一半"
                />
              </div>
            </CardContent>
          </Card>

          {sections.length === 0 ? (
            <div className="flex flex-col items-center gap-3 rounded-lg border border-dashed py-12">
              <p className="text-sm text-muted-foreground">
                還沒有廠商區塊，先新增要叫貨的廠商
              </p>
              <Button type="button" variant="outline" onClick={addSection}>
                <Plus className="size-4" /> 新增廠商區塊
              </Button>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {sections.map((sec, si) => (
                <Card key={si}>
                  <CardHeader className="flex-row flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <Label>廠商 *</Label>
                      <Select value={sec.vendorId} onValueChange={(v) => updateSectionVendor(si, v)}>
                        <SelectTrigger className="w-44">
                          <SelectValue placeholder="選擇廠商" />
                        </SelectTrigger>
                        <SelectContent>
                          {vendors.map((v) => (
                            <SelectItem key={v.id} value={v.id}>
                              {v.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button type="button" variant="outline" size="sm" onClick={() => addRow(si)}>
                        <Plus className="size-4" /> 新增明細
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => addRowFromPrice(si)}
                      >
                        <BookOpen className="size-4" /> 從價格表帶入
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        title="移除此廠商區塊"
                        onClick={() => removeSection(si)}
                      >
                        <X className="size-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {sec.rows.length === 0 ? (
                      <p className="py-4 text-center text-sm text-muted-foreground">
                        此廠商還沒有明細
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <div className="min-w-[640px]">
                          <div className="grid grid-cols-[1.4fr_1fr_1fr_0.6fr_0.8fr_1fr_2rem] gap-2 border-b pb-2 text-xs font-medium text-muted-foreground">
                            <span>色號</span>
                            <span>尺寸</span>
                            <span>規格</span>
                            <span className="text-right">數量</span>
                            <span className="text-right">單價</span>
                            <span>備註</span>
                            <span />
                          </div>
                          {sec.rows.map((it) => (
                            <div
                              key={it.key}
                              className="grid grid-cols-[1.4fr_1fr_1fr_0.6fr_0.8fr_1fr_2rem] items-center gap-2 border-b py-2"
                            >
                              <Input
                                value={it.product_name}
                                onChange={(e) => updateItem(si, it.key, { product_name: e.target.value })}
                                onBlur={() => autoFillPrice(si, it.key)}
                                placeholder="色號"
                              />
                              <Input
                                value={it.size}
                                onChange={(e) => updateItem(si, it.key, { size: e.target.value })}
                                placeholder="尺寸"
                              />
                              <Input
                                value={it.spec}
                                onChange={(e) => updateItem(si, it.key, { spec: e.target.value })}
                                placeholder="規格"
                              />
                              <Input
                                type="number"
                                min={0}
                                step="0.01"
                                value={it.quantity}
                                onChange={(e) => updateItem(si, it.key, { quantity: e.target.value })}
                                placeholder="0"
                              />
                              <Input
                                type="number"
                                min={0}
                                step="0.01"
                                value={it.unit_price}
                                onChange={(e) => updateItem(si, it.key, { unit_price: e.target.value })}
                                placeholder="0"
                              />
                              <Input
                                value={it.notes}
                                onChange={(e) => updateItem(si, it.key, { notes: e.target.value })}
                                placeholder="備註"
                              />
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                title="移除"
                                onClick={() => removeItem(si, it.key)}
                              >
                                <Trash2 className="size-4 text-destructive" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}

              <div className="flex items-center justify-between">
                <Button type="button" variant="outline" onClick={addSection}>
                  <Plus className="size-4" /> 新增另一位廠商
                </Button>
                <p className="text-sm text-muted-foreground">
                  共 {sections.reduce((n, s) => n + s.rows.filter((r) => r.product_name.trim() !== "").length, 0)} 筆明細
                </p>
              </div>
            </div>
          )}
        </>
      )}

      <Dialog open={!!picker} onOpenChange={(o) => !o && setPicker(null)}>
        <DialogContent className="max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>從價格表帶入</DialogTitle>
          </DialogHeader>
          {prices.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              此廠商尚無價格資料，可以先手動輸入，或到「價格表」頁面建立
            </p>
          ) : (
            <div className="flex flex-col">
              {prices.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => applyPrice(p)}
                  className="flex items-center justify-between gap-4 rounded-lg border-b px-2 py-3 text-left transition-colors last:border-b-0 hover:bg-accent"
                >
                  <div>
                    <p className="text-sm font-medium">{p.productName}</p>
                    <p className="text-xs text-muted-foreground">
                      {[p.spec, p.unit].filter(Boolean).join(" / ") || "—"}
                    </p>
                  </div>
                  <span className="text-sm font-semibold tabular-nums">
                    {fmtMoney(Number(p.unitPrice))}
                  </span>
                </button>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </form>
  );
}
