import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, Printer } from "lucide-react";
import { collection, doc, getDoc, getDocs, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { fetchInChunks } from "@/lib/firestore-helpers";
import type { Order, OrderItem } from "@/lib/types";
import { useAuth } from "@/hooks/use-auth";
import OrderSheets from "@/components/order/order-sheets";
import { Button } from "@/components/ui/button";

export default function BatchPrint() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const uid = user?.id ?? "";
  const [searchParams] = useSearchParams();
  const ids = useMemo(
    () => searchParams.get("ids")?.split(",").filter(Boolean) ?? [],
    [searchParams],
  );

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["batch-orders", uid, ids],
    enabled: ids.length > 0 && !!uid,
    queryFn: async () => {
      const snaps = await Promise.all(
        ids.map(async (oid) => {
          const d = await getDoc(doc(db, "orders", oid));
          return d.exists() ? ({ id: d.id, ...d.data() } as Order) : null;
        }),
      );
      return snaps
        .filter((o): o is Order => o !== null)
        .sort((a, b) => a.orderDate.localeCompare(b.orderDate));
    },
  });

  const orderIds = useMemo(() => orders.map((o) => o.id), [orders]);

  const { data: items = [] } = useQuery({
    queryKey: ["batch-items", uid, orderIds],
    enabled: orderIds.length > 0 && !!uid,
    queryFn: async () => {
      return fetchInChunks<OrderItem>("orderItems", "orderId", orderIds, uid);
    },
  });

  const itemsByOrder = useMemo(() => {
    const map = new Map<string, OrderItem[]>();
    for (const it of items) {
      const list = map.get(it.orderId) ?? [];
      list.push(it);
      map.set(it.orderId, list);
    }
    return map;
  }, [items]);

  return (
    <div className="flex flex-col gap-4">
      {/* Toolbar (hidden when printing) */}
      <div className="print-hidden flex flex-wrap items-center justify-between gap-3">
        <Button variant="ghost" onClick={() => navigate("/orders")}>
          <ArrowLeft className="size-4" /> 返回叫貨單
        </Button>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            共 {orders.length} 位客戶
          </span>
          <Button onClick={() => window.print()} disabled={orders.length === 0}>
            <Printer className="size-4" /> 列印 / 存成 PDF
          </Button>
        </div>
      </div>

      {isLoading ? (
        <p className="py-16 text-center text-sm text-muted-foreground">載入中…</p>
      ) : orders.length === 0 ? (
        <p className="py-16 text-center text-sm text-muted-foreground">
          沒有選取任何叫貨單
        </p>
      ) : (
        <div className="flex flex-col gap-6">
          {orders.map((o) => (
            <OrderSheets key={o.id} order={o} items={itemsByOrder.get(o.id) ?? []} />
          ))}
        </div>
      )}
    </div>
  );
}
