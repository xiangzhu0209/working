import { useState, type FormEvent } from "react";
import { Navigate } from "react-router-dom";
import { ReceiptText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";

export default function Login() {
  const { user, loading, signIn, signUp } = useAuth();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (loading) return null;
  if (user) return <Navigate to="/orders" replace />;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast("請輸入信箱與密碼");
      return;
    }
    if (mode === "signup" && !name.trim()) {
      toast("請輸入您的姓名");
      return;
    }
    setSubmitting(true);
    const { error } =
      mode === "login"
        ? await signIn(email, password)
        : await signUp(email, password, name.trim());
    setSubmitting(false);
    if (error) {
      toast(error, { duration: 5000 });
      return;
    }
    if (mode === "signup") {
      toast("註冊成功，已自動登入");
    }
  };

  return (
    <div className="flex min-h-full items-center justify-center bg-muted/40 p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="items-center text-center">
          <span className="mb-2 flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <ReceiptText className="size-6" />
          </span>
          <CardTitle className="text-xl">叫貨單系統</CardTitle>
          <CardDescription>
            {mode === "login" ? "登入您的帳號" : "建立新帳號"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {mode === "signup" && (
              <div className="flex flex-col gap-2">
                <Label htmlFor="name">姓名 *</Label>
                <Input
                  id="name"
                  autoComplete="name"
                  placeholder="例如：王小明"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
            )}
            <div className="flex flex-col gap-2">
              <Label htmlFor="email">信箱</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="password">密碼</Label>
              <Input
                id="password"
                type="password"
                autoComplete={mode === "login" ? "current-password" : "new-password"}
                placeholder="至少 6 碼"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={submitting}>
              {submitting ? "處理中…" : mode === "login" ? "登入" : "註冊"}
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setMode(mode === "login" ? "signup" : "login")}
            >
              {mode === "login" ? "沒有帳號？註冊" : "已有帳號？登入"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
