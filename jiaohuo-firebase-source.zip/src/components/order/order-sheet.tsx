import type { Order, OrderItem } from "@/lib/types";
import { fmtMoney, statusLabel, toNum } from "@/lib/order-utils";
import { Badge } from "@/components/ui/badge";

/**
 * A single A4-style 叫貨單 sheet. When `showVendorColumn` is true all vendors'
 * items are listed together with a 廠商 column (one customer, one sheet);
 * otherwise the sheet shows a single vendor's items with the vendor name in the
 * header.
 */
export default function OrderSheet({
  order,
  items,
  issuer,
  vendorName,
  showVendorColumn,
}: {
  order: Order;
  items: OrderItem[];
  issuer: string;
  vendorName?: string;
  showVendorColumn?: boolean;
}) {
  return (
    <div className="rounded-lg border bg-card p-6">
      {/* Sheet header */}
      <div className="mb-3 flex items-start justify-between border-b pb-2">
        <div>
          <h1 className="text-xl font-bold tracking-wide">叫貨單</h1>
          <p className="mt-0.5 text-xs text-muted-foreground">
            單號：{order.order_no} · 狀態：
            <Badge variant="outline">{statusLabel(order.status)}</Badge>
          </p>
        </div>
        <div className="text-right text-sm">
          <p>日期：{order.order_date}</p>
          {vendorName && <p className="mt-0.5 text-base font-semibold">{vendorName}</p>}
        </div>
      </div>

      {/* Info */}
      <div className="mb-3 grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
        <p>
          <span className="text-xs text-muted-foreground">客戶名：</span>
          <span className="font-medium">{order.customer_name || "—"}</span>
        </p>
        <p>
          <span className="text-xs text-muted-foreground">案名：</span>
          <span className="font-medium">{order.project_name || "—"}</span>
        </p>
        <p className="col-span-2">
          <span className="text-xs text-muted-foreground">訂單備註：</span>
          <span className="font-medium">{order.notes || "—"}</span>
        </p>
      </div>

      {/* Items */}
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b-2 border-foreground text-left">
            <th className="w-8 py-1 pr-2 font-semibold">項次</th>
            {showVendorColumn && <th className="py-1 pr-2 font-semibold">廠商</th>}
            <th className="py-1 pr-2 font-semibold">色號</th>
            <th className="py-1 pr-2 font-semibold">尺寸</th>
            <th className="py-1 pr-2 font-semibold">規格</th>
            <th className="w-12 py-1 pr-2 text-right font-semibold">數量</th>
            <th className="w-16 py-1 pr-2 text-right font-semibold">單價</th>
            <th className="py-1 font-semibold">備註</th>
          </tr>
        </thead>
        <tbody>
          {items.map((it, idx) => (
            <tr key={it.id} className="border-b">
              <td className="py-1 pr-2 text-muted-foreground">{idx + 1}</td>
              {showVendorColumn && (
                <td className="py-1 pr-2 font-medium">{it.vendorName || "—"}</td>
              )}
              <td className="py-1 pr-2 font-medium">{it.product_name}</td>
              <td className="py-1 pr-2">{it.size || "—"}</td>
              <td className="py-1 pr-2">{it.spec || "—"}</td>
              <td className="py-1 pr-2 text-right tabular-nums">{it.quantity}</td>
              <td className="py-1 pr-2 text-right tabular-nums">{fmtMoney(toNum(it.unit_price))}</td>
              <td className="py-1">{it.notes || "—"}</td>
            </tr>
          ))}
          {items.length === 0 && (
            <tr>
              <td
                colSpan={showVendorColumn ? 8 : 7}
                className="py-4 text-center text-muted-foreground"
              >
                沒有明細
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* 出單人 */}
      <div className="mt-4 flex justify-end text-sm">
        <p>
          出單人：
          {issuer ? (
            <span className="ml-1 font-medium">{issuer}</span>
          ) : (
            <span className="ml-1 inline-block w-24 border-b border-dotted border-foreground/40" />
          )}
        </p>
      </div>
    </div>
  );
}
