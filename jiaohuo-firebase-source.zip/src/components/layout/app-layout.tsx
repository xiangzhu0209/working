import { useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import {
  Calculator,
  Handshake,
  LogOut,
  Menu,
  Pencil,
  ReceiptText,
  Tags,
  type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const NAV_ITEMS: { to: string; label: string; icon: LucideIcon }[] = [
  { to: "/orders", label: "叫貨單", icon: ReceiptText },
  { to: "/reconciliation", label: "月對帳", icon: Calculator },
  { to: "/vendors", label: "廠商", icon: Handshake },
  { to: "/prices", label: "價格表", icon: Tags },
];

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav className="flex flex-col gap-1">
      {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          onClick={onNavigate}
          className={({ isActive }) =>
            cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              isActive
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-accent hover:text-foreground",
            )
          }
        >
          <Icon className="size-4 shrink-0" />
          {label}
        </NavLink>
      ))}
    </nav>
  );
}

function SidebarFooter() {
  const { user, profileName, signOut, updateProfile } = useAuth();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);

  const openEdit = () => {
    setName(profileName);
    setOpen(true);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      toast("請輸入姓名");
      return;
    }
    setSaving(true);
    const { error } = await updateProfile(name);
    setSaving(false);
    if (error) {
      toast(`儲存失敗：${error}`);
      return;
    }
    toast("姓名已更新");
    setOpen(false);
  };

  return (
    <>
      <div className="flex flex-col gap-3">
        <Separator />
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">
              {profileName || user?.email || "未登入"}
            </p>
            <p className="truncate text-xs text-muted-foreground">
              {profileName ? user?.email : "點鉛筆設定姓名"}
            </p>
          </div>
          <div className="flex items-center">
            <Button variant="ghost" size="icon" title="設定姓名" onClick={openEdit}>
              <Pencil className="size-4" />
            </Button>
            <Button variant="ghost" size="icon" title="登出" onClick={() => void signOut()}>
              <LogOut className="size-4" />
            </Button>
          </div>
        </div>
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>設定姓名</DialogTitle>
            <DialogDescription>
              您的姓名會印在叫貨單的「出單人」欄位
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            <Label htmlFor="profile-name">姓名</Label>
            <Input
              id="profile-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="例如：王小明"
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              取消
            </Button>
            <Button onClick={() => void handleSave()} disabled={saving}>
              {saving ? "儲存中…" : "儲存"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default function AppLayout() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="flex h-full w-full">
      {/* Desktop sidebar */}
      <aside className="print-hidden hidden w-64 shrink-0 flex-col gap-6 border-r bg-card px-4 py-6 md:flex">
        <Link to="/orders" className="flex items-center gap-2 px-2">
          <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <ReceiptText className="size-5" />
          </span>
          <span className="text-lg font-semibold tracking-tight">叫貨單系統</span>
        </Link>
        <div className="flex flex-1 flex-col justify-between">
          <NavLinks />
          <SidebarFooter />
        </div>
      </aside>

      {/* Mobile header */}
      <header className="print-hidden flex items-center justify-between border-b bg-card px-4 py-3 md:hidden">
        <Link to="/orders" className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <ReceiptText className="size-4" />
          </span>
          <span className="font-semibold">叫貨單系統</span>
        </Link>
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="size-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64">
            <SheetTitle className="sr-only">選單</SheetTitle>
            <div className="flex h-full flex-col justify-between py-2">
              <NavLinks onNavigate={() => setMenuOpen(false)} />
              <SidebarFooter />
            </div>
          </SheetContent>
        </Sheet>
      </header>

      {/* Content */}
      <main className="h-full flex-1 overflow-y-auto bg-background">
        <div className="mx-auto max-w-5xl p-4 md:p-8 print:max-w-none print:p-0">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
